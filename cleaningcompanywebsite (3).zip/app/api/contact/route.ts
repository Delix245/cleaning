import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()

    // Extract form fields
    const name = formData.get("name") as string
    const phone = formData.get("phone") as string
    const email = formData.get("email") as string
    const address = formData.get("address") as string
    const state = formData.get("state") as string
    const services = formData.get("services") as string
    const packages = formData.get("packages") as string
    const paymentMethod = formData.get("paymentMethod") as string
    const message = formData.get("message") as string

    // Validate required fields
    if (!name || !phone || !email || !address || !state || !services || !paymentMethod) {
      return NextResponse.json({ error: "All required fields must be filled" }, { status: 400 })
    }

    // Extract files
    const files: File[] = []
    const fileEntries = Array.from(formData.entries()).filter(([key]) => key.startsWith("file_"))

    for (const [, file] of fileEntries) {
      if (file instanceof File && file.size > 0) {
        files.push(file)
      }
    }

    // Prepare attachments for Brevo
    const attachments = []
    for (const file of files) {
      const buffer = await file.arrayBuffer()
      const base64Content = Buffer.from(buffer).toString("base64")

      attachments.push({
        name: file.name,
        content: base64Content,
      })
    }

    // Prepare email content
    const emailSubject = `New Contact Form Submission - ${name}`
    const emailContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0A5189; border-bottom: 2px solid #3D8B7D; padding-bottom: 10px;">
          New Contact Form Submission from EcoClean Website
        </h2>
        
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #0A5189; margin-top: 0;">Contact Information</h3>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Phone:</strong> <a href="tel:${phone}">${phone}</a></p>
          <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
          <p><strong>Address:</strong> ${address}</p>
          <p><strong>State:</strong> ${state}</p>
        </div>

        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #0A5189; margin-top: 0;">Service Details</h3>
          <p><strong>Services Requested:</strong> ${services}</p>
          ${packages ? `<p><strong>Packages:</strong> ${packages}</p>` : ""}
          <p><strong>Preferred Payment Method:</strong> ${paymentMethod}</p>
        </div>

        ${
          message
            ? `
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #0A5189; margin-top: 0;">Additional Message</h3>
          <p style="white-space: pre-wrap;">${message}</p>
        </div>
        `
            : ""
        }

        ${
          files.length > 0
            ? `
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #0A5189; margin-top: 0;">Attached Files</h3>
          <p>${files.length} file(s) attached to this email:</p>
          <ul>
            ${files.map((file) => `<li>${file.name} (${(file.size / 1024).toFixed(1)} KB)</li>`).join("")}
          </ul>
        </div>
        `
            : ""
        }
        
        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
        <p style="color: #666; font-size: 12px; text-align: center;">
          <em>This email was sent from the EcoClean website contact form.</em><br>
          <em>Submitted on: ${new Date().toLocaleString()}</em>
        </p>
      </div>
    `

    // Prepare email data for Brevo API
    const emailData = {
      sender: {
        name: "EcoClean Website",
        email: "827469001@smtp-brevo.com",
      },
      to: [
        {
          email: "harabugaslava@gmail.com",
          name: "EcoClean Admin",
        },
      ],
      replyTo: {
        email: email,
        name: name,
      },
      subject: emailSubject,
      htmlContent: emailContent,
      ...(attachments.length > 0 && { attachment: attachments }),
    }

    // Send email using Brevo API
    const brevoResponse = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": "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",
      },
      body: JSON.stringify(emailData),
    })

    if (!brevoResponse.ok) {
      const errorData = await brevoResponse.json()
      console.error("Brevo API error:", errorData)
      return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
    }

    const result = await brevoResponse.json()
    console.log("Email sent successfully to unisynchomecenter@gmail.com", result)

    return NextResponse.json(
      {
        message: "Contact form submitted successfully",
        filesAttached: files.length,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Error processing contact form:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
